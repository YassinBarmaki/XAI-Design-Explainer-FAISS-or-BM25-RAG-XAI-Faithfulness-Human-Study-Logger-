# XAI Design Explainer
Quickstart: `pip install -r requirements.txt && python app.py`